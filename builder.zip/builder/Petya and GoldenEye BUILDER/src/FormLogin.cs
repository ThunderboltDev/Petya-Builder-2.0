﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Petya_and_GoldenEye_BUILDER.src
{

    public partial class FormLogin : Form
    {
        private string password = "petya";

        public FormLogin()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;  // or FormBorderStyle.Fixed3D
            this.MaximizeBox = false;
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string enteredPassword = textBox1.Text;

            if (enteredPassword == password)
            {
                Form1 TOS2 = new Form1();
                TOS2.Show();

                this.Hide();
            }
            else
            {
                MessageBox.Show("Incorrect password. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
