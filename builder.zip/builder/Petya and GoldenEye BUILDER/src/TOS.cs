﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Petya_and_GoldenEye_BUILDER
{
    public partial class TOS : Form
    {
        public TOS()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;  // or FormBorderStyle.Fixed3D
            this.MaximizeBox = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {

                this.Hide();
            }
            else
            {
                MessageBox.Show("Please agree to the Terms and Service.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void TOS_Load(object sender, EventArgs e)
        {

        }
    }
}
